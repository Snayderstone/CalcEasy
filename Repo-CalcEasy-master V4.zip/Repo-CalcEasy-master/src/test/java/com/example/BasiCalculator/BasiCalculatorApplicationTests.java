package com.example.BasiCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasiCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
