/*/const rootElement = document.getElementById("root");

ReactDOM.render(
    React.createElement('div', null, 'Hola Mundo'),
    rootElement
);*/
// Componente principal de la calculadora
// Componente CalculatorApp
const CalculatorApp = () => {
    const [input, setInput] = React.useState(''); // Estado para almacenar la entrada del usuario
    const [result, setResult] = React.useState('');
    const [history, setHistory] = React.useState([]);
    const [darkMode, setDarkMode] = React.useState(false); // Estado para el modo oscuro
    const [error, setError] = React.useState(''); // Estado para almacenar mensajes de error
    const [hasResult, setHasResult] = React.useState(false); // Estado para indicar si se ha mostrado un resultado

    const handleInput = (value) => {
        if (input.length >= 15) {
            setError('Máximo de 15 caracteres alcanzado');
            return;
        }

        // Limpiar la pantalla si se está ingresando un número después de un resultado
        if (hasResult && /[0-9.]/.test(value)) {
            setInput(value);
            setHasResult(false);
            return;
        }

        // Validar el punto decimal para que no se ingrese más de una vez en un número
        if (value === '.') {
            const lastNumber = input.split(/[-+*/]/).pop();
            if (lastNumber.includes('.')) {
                return;
            }
        }

        // Validar que los decimales no sean más de 6
        const lastNumber = input.split(/[-+*/]/).pop();
        if (lastNumber.includes('.') && lastNumber.split('.')[1].length >= 6) {
            setError('Máximo de 6 decimales alcanzado');
            return;
        }

        if (/[+\-*/]/.test(value)) {
            // Si es un operador y hay una operación completa, realizar la operación
            if (input.match(/(-?\d+(\.\d{0,6})?)([-+*/])(-?\d+(\.\d{0,6})?)/)) {
                performOperation(input, value);
            } else {
                setInput(prevInput => prevInput + value);
            }
        } else {
            // Si es un número o punto, simplemente agregarlo a la entrada
            setInput(prevInput => prevInput + value);
        }
    };

    const handleDelete = () => {
        setInput(prevInput => prevInput.slice(0, -1));
    };

    const handleClear = () => {
        setInput('');
        setResult('');
        setError('');
        setHasResult(false);
    };

    const handleClearHistory = () => {
        setHistory([]);
    };

    const performOperation = (currentInput, nextOperator = '') => {
        let num1, num2, operator;
        const match = currentInput.match(/(-?\d+(\.\d{0,6})?)([-+*/])(-?\d+(\.\d{0,6})?)/);
        if (!match) {
            setError('Entrada inválida');
            return;
        }

        const [, number1, , currentOperator, number2] = match;
        num1 = parseFloat(number1);
        num2 = parseFloat(number2);
        operator = currentOperator;

        const operationTypeMap = {
            '+': 'suma',
            '-': 'resta',
            '*': 'multiplicacion',
            '/': 'division'
        };

        const operationType = operationTypeMap[operator];
        if (!operationType) {
            setError('Operador no reconocido');
            return;
        }

        axios.get(`http://localhost:8080/calculadora/operar?tipoOperacion=${operationType}&num1=${num1}&num2=${num2}`)
            .then(response => {
                let numero = parseFloat(response.data.split(' ')[1]);
                numero = parseFloat(numero.toFixed(6)); // Limitar el resultado a 6 decimales
                setResult(numero);
                fetchHistory();
                if (nextOperator) {
                    setInput(`${numero}${nextOperator}`);
                } else {
                    setInput(`${numero}`);
                }
                setError(''); // Limpiar error al completar la operación con éxito
                setHasResult(true); // Indicar que se ha mostrado un resultado
            })
            .catch(error => {
                console.error('Error al realizar la operación:', error);
                if (error.response && error.response.data) {
                    setError(error.response.data); // Mostrar mensaje de error de la API
                } else {
                    setError('Error al realizar la operación');
                }
                setResult('Error');
                setHasResult(true); // Indicar que se ha mostrado un resultado
            });
    };

    const fetchHistory = () => {
        axios.get('http://localhost:8080/calculadora/historial')
            .then(response => setHistory(response.data))
            .catch(error => console.error('Error al obtener el historial:', error));
    };

    React.useEffect(() => {
        fetchHistory();
        // Enfocar automáticamente el input al cargar la calculadora
        document.getElementById('Principal').focus();
    }, []);

    const toggleDarkMode = () => {
        setDarkMode(prevMode => !prevMode);
    };

    React.useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const closeModal = () => {
        setError('');
    };

    const handleKeyDown = (event) => {
        // Capturar la tecla presionada y manejarla
        const key = event.key;

        if (key === 'Enter') {
            performOperation(input);
        } else if (key === 'Backspace') {
            handleDelete();
        } else if (/^\d+$|[+\-*\/]/.test(key) || key === '.') {
            handleInput(key);
        }
    };

    return (
        <div id="Principal" tabIndex="0" onKeyDown={handleKeyDown} style={{ outline: 'none' }}>
            <div id="Calculadora">
                
                <div id="Pantalla">{input || result}</div>
                <div id="Teclado">
                    <button className="button c" onClick={handleClear}>AC</button>
                    <button className="button ra" onClick={handleDelete}>DEL</button>
                    <button className="button" onClick={() => handleInput('/')}>÷</button>

                    <button className="button" onClick={() => handleInput('7')}>7</button>
                    <button className="button" onClick={() => handleInput('8')}>8</button>
                    <button className="button" onClick={() => handleInput('9')}>9</button>
                    <button className="button" onClick={() => handleInput('*')}>×</button>

                    <button className="button" onClick={() => handleInput('4')}>4</button>
                    <button className="button" onClick={() => handleInput('5')}>5</button>
                    <button className="button" onClick={() => handleInput('6')}>6</button>
                    <button className="button" onClick={() => handleInput('+')}>+</button>

                    <button className="button" onClick={() => handleInput('1')}>1</button>
                    <button className="button" onClick={() => handleInput('2')}>2</button>
                    <button className="button" onClick={() => handleInput('3')}>3</button>
                    <button className="button" onClick={() => handleInput('-')}>−</button>

                    <button className="button" onClick={() => handleInput('0')}>0</button>
                    <button className="button pu" onClick={() => handleInput('.')}>.</button>

                    <button className="button igual" onClick={() => performOperation(input)}>=</button>
                </div>
            </div>
            <div id="Historial">
                <h2>Historial</h2>
                <ul>
                    {history.map((entry, index) => (
                        <li key={index}>
                            {entry.num1} {entry.tipoOperacion} {entry.num2} = {entry.resultado}
                        </li>
                    ))}
                </ul>
                <button onClick={handleClearHistory}>Limpiar Historial</button>
            </div>
            {error && (
                <div id="ErrorDialog">
                    <p>{error}</p>
                    <button onClick={closeModal}>Cerrar</button>
                </div>
            )}
        </div>
    );
};

ReactDOM.render(<CalculatorApp />, document.getElementById('root'));