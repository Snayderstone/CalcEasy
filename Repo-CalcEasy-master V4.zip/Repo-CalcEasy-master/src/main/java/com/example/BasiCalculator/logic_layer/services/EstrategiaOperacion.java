package com.example.BasiCalculator.logic_layer.services;

public interface EstrategiaOperacion {
    double realizarOperacion(double num1, double num2);
}
