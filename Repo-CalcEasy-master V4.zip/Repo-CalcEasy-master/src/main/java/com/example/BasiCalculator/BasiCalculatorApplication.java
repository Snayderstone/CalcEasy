package com.example.BasiCalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasiCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasiCalculatorApplication.class, args);
	}

}
