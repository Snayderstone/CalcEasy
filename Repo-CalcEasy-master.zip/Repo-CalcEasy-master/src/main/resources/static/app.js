/*/const rootElement = document.getElementById("root");

ReactDOM.render(
    React.createElement('div', null, 'Hola Mundo'),
    rootElement
);*/
// Componente principal de la calculadora
// Componente CalculatorApp
const CalculatorApp = () => {
    const [input, setInput] = React.useState(''); // Estado para almacenar la entrada del usuario
    const [result, setResult] = React.useState('');
    const [history, setHistory] = React.useState([]);
    const [darkMode, setDarkMode] = React.useState(false); // Estado para el modo oscuro
    const [error, setError] = React.useState(''); // Estado para almacenar mensajes de error

    const handleInput = (value) => {
        if (/[0-9+\-*/.]/.test(value)) {
            setInput(prevInput => prevInput + value);
        }
    };

    const handleDelete = () => {
        setInput(prevInput => prevInput.slice(0, -1));
    };

    const handleClear = () => {
        setInput('');
        setResult('');
        setError('');
    };

    const handleClearHistory = () => {
        setHistory([]);
    };

    const performOperation = () => {
        let num1, num2;
        const match = input.match(/(\d+(\.\d+)?)([-+*/])(\d+(\.\d+)?)/);
        if (!match) {
            setError('Entrada inválida');
            return;
        }

        const [, number1, , operator, number2] = match;
        num1 = parseFloat(number1);
        num2 = parseFloat(number2);

        const operationTypeMap = {
            '+': 'suma',
            '-': 'resta',
            '*': 'multiplicacion',
            '/': 'division'
        };

        const operationType = operationTypeMap[operator];
        if (!operationType) {
            setError('Operador no reconocido');
            return;
        }

        axios.get(`http://localhost:8080/calculadora/operar?tipoOperacion=${operationType}&num1=${num1}&num2=${num2}`)
            .then(response => {
                const numero = parseFloat(response.data.split(' ')[1]);
                setResult(numero);
                fetchHistory();
                setInput(`${numero}`);
                setError(''); // Limpiar error al completar la operación con éxito
            })
            .catch(error => {
                console.error('Error al realizar la operación:', error);
                if (error.response && error.response.data) {
                    setError(error.response.data); // Mostrar mensaje de error de la API
                } else {
                    setError('Error al realizar la operación');
                }
                setResult('Error');
            });
    };

    const fetchHistory = () => {
        axios.get('http://localhost:8080/calculadora/historial')
            .then(response => setHistory(response.data))
            .catch(error => console.error('Error al obtener el historial:', error));
    };

    React.useEffect(() => {
        fetchHistory();
        // Enfocar automáticamente el input al cargar la calculadora
                document.getElementById('Principal').focus();
    }, []);

    const toggleDarkMode = () => {
        setDarkMode(prevMode => !prevMode);
    };

    React.useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const closeModal = () => {
            setError('');
        };

    const handleKeyDown = (event) => {
            // Capturar la tecla presionada y manejarla
            const key = event.key;

            if (key === 'Enter') {
                performOperation();
            } else if (key === 'Backspace') {
                handleDelete();
            } else if (/^\d+$|[+\-*\/]/.test(key)) {
                handleInput(key);
            }
        };

    return (
        <div id="Principal" tabIndex="0" onKeyDown={handleKeyDown} style={{ outline: 'none' }}>
            <div id="Calculadora">
                <button onClick={toggleDarkMode}>
                    {darkMode ? 'Modo Claro' : 'Modo Oscuro'}
                </button>
                <div id="Pantalla">{input || result}</div>
                <div id="Teclado">
                    <button className="button c" onClick={handleClear}>C</button>
                    <button className="button ra" onClick={handleDelete}>←</button>
                    <button className="button" onClick={() => handleInput('/')}>÷</button>

                    <button className="button" onClick={() => handleInput('7')}>7</button>
                    <button className="button" onClick={() => handleInput('8')}>8</button>
                    <button className="button" onClick={() => handleInput('9')}>9</button>
                    <button className="button" onClick={() => handleInput('*')}>×</button>

                    <button className="button" onClick={() => handleInput('4')}>4</button>
                    <button className="button" onClick={() => handleInput('5')}>5</button>
                    <button className="button" onClick={() => handleInput('6')}>6</button>
                    <button className="button" onClick={() => handleInput('+')}>+</button>

                    <button className="button" onClick={() => handleInput('1')}>1</button>
                    <button className="button" onClick={() => handleInput('2')}>2</button>
                    <button className="button" onClick={() => handleInput('3')}>3</button>
                    <button className="button" onClick={() => handleInput('-')}>−</button>

                    <button className="button" onClick={() => handleInput('0')}>0</button>
                    <button className="button pu" onClick={() => handleInput('.')}>.</button>

                    <button className="button igual" onClick={performOperation}>=</button>
                </div>
            </div>
            <div id="Historial">
                <h2>Historial</h2>
                <ul>
                    {history.map((entry, index) => (
                        <li key={index}>
                            {entry.num1} {entry.tipoOperacion} {entry.num2} = {entry.resultado}
                        </li>
                    ))}
                </ul>
                <button onClick={handleClearHistory}>Limpiar Historial</button>
            </div>
            {error && (
                            <div id="ErrorDialog">
                                <p>{error}</p>
                                <button onClick={closeModal}>Cerrar</button>
                            </div>
                        )}

        </div>
    );
};

ReactDOM.render(<CalculatorApp />, document.getElementById('root'));